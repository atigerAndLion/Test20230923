/*
 * File:   user_bms.h
 * Author: AID
 *
 * Created on 20200320
 */
 #ifndef __USER_BMS_H
#define __USER_BMS_H
#include "main.h"

#define VCELL_Dsg_DEF_ERR     500
#define VCELL_Chg_DEF_ERR     200 //191105 
#define VCELL_Dsg_DEF_WAR     400
#define VCELL_Chg_DEF_WAR     150 //191105

//V = NTC10K+10K  3.3V   AD = (RT/RT+10000)*3300*4096/3300
//VTSX = AD*382 ��V
//RTS = 10000*VTSX/(3.3-VTSX)
//VTSX = 3.3RTS/(10000+RTS)
//AD = 3.3RTS/(10000+RTS)/382
#define NTC_CHG_OTP				2791//2840			//4.9K   AD = X*4096
#define NTC_CHG_OTP_CLEAR		3110//3171			//5.8K
#define NTC_DCH_OTP 			1970				//2.6K
#define NTC_DCH_OTP_CLEAR		2222				//3k

#define NTC_CHG_LTP				6377			//0
#define NTC_CHG_LTP_CLEAR		6000			//5
#define NTC_DCH_LTP				7622			//-20
#define NTC_DCH_LTP_CLEAR		7349			//-15

#define NTC_SHORT				0
#define NTC_OPEN				1

#define NTC_ERR_SHORT							8200
#define NTC_ERR_OPEN							660			//569K

#define VBAT_FULL					      	82000			//31v
#define VBAT_FULL_CLEAR      				80000   		//33V

// AD = V*3/53*4096/3300 =
#define VPACK_OVP								2978//42V        // 3191   // 45V
#define VPACK_CONNECT						2840 // 40.05V   //2837   // 40V
#define VPACK_NCONT							2766   // 39V


#define ICUR_DCH_STATE     	 		35//300mA  // AD = I*100/844
#define ICUR_DCH_OCP     	 			3554	  // 30A I =
#define	ICUR_DCH_OCP2				6666
#define ICUR_DCH_OCP_30S     	 	2962	  // 25A I =
#define ICUR_CHG_STATE      	 	23	  //I = 200
#define ICUR_CHG_OCP      	 		829	  //7A

#define ICUR_DCH_MOS_ERR            300

#define VCELL_ERR								2000
#define VCELL_DEF								1000

#define VCELL_OVP								4200
#define VCELL_OVP_CLEAR							4100

#define VCELL_UVP								2700
#define VCELL_UVP_CLEAR							3000

#define VBAT_UVP								34000 //34V
#define VBAT_UVP_CLEAR							33000 //33V

#define GC_DELAY_05S						50
#define GC_DELAY_1S							100
#define GC_DELAY_2S							200
#define GC_DELAY_4S							40
#define GC_DELAY_10S						1000

void State_Change_Function(void);
void Voltage_Protect_Function(void);
void Current_Protect_Function(void);
void Temperature_Protect_Function(void);
void MOS_Control_Function(void);
void Adapter_Function(void);
void AFE_Update_Function(void);
void ADC_Function(void);
 
#endif
