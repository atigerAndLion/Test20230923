

/* Define to prevent recursive inclusion -------------------------------------------------------------------*/
#ifndef __SOFT_SOC_H
#define __SOFT_SOC_H
#include "main.h"
#define CAP_CNT_VAL 		14550   //14400   //1mah
#define CUR_DSG_050mA   		50			// mA


typedef union
{
	struct{
		long	cap_cnt;
				
		u16  	full_cap;
		u16    bat_cap;
	  u16    bat_cycle_cnt;
		u16  	re_cap_rate;
		u8  	re_cap_rate_volt;
		u8		chg_cap_cnt;
		u8		fcc_index;
		u8    soh;
		u16    low_temp_bat_cap;
		u16    low_temp_re_cap_rate;
	}val;
}SystemCap;

extern volatile SystemCap  sys_cap;

void Soc_AddSub(void);
void NormalCapacityProc(void);
u8 VbatToSoc(u16 bat_val);
void Cap_Update_Check(void);
void FullCap_Update(void);
void BatCycleProc(void);
void Power_On_SOC(void);

#endif /* __SPI_FLASH_AUTO_H -------------------------------------------------------------------------------*/
