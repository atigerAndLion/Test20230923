/*
 * File:   user_bms.c
 * Author: AID
 *
 * Created on 20200320
 */
#include "i2c_sh367309.h"
#include "user_bms.h"


u16 vin_val;

 void AFE_Update_Function()
 {
	 UpdateDataFromSH367309();
 }

 void State_Change_Function()
 {
	Adapter_Function();
	Voltage_Protect_Function();
	Current_Protect_Function();
	Temperature_Protect_Function();
 }
 
 void ADC_Function()
 {
	 
 }
 
 void Adapter_Function()
 {
	static u8 adapter_connect_cnt =0;
	
	if(sys_flags.flag.adapter_int_flag == 1)
	{
		sys_flags.flag.adapter_connect_flag =1;
		sys_flags.flag.adapter_int_flag =0;
		adapter_connect_cnt = GC_DELAY_1S;
	}
	if(vin_val > VPACK_CONNECT)
	{
		adapter_connect_cnt++;
		if(adapter_connect_cnt >GC_DELAY_1S)
		{
			adapter_connect_cnt = GC_DELAY_1S;
			sys_flags.flag.adapter_connect_flag =1;
		}
	}
	else
	{
		if(sys_flags.flag.adapter_connect_flag ==1)
		{
			if(adapter_connect_cnt < VPACK_NCONT)
			{
				if(adapter_connect_cnt>0)
				{
					adapter_connect_cnt--;
				}
				else
				{
					sys_flags.flag.adapter_connect_flag =0;
				}
			}
			else
			{
				adapter_connect_cnt = GC_DELAY_1S;
			}
		}
		else
		{
			adapter_connect_cnt = 0;
		}
	}
 }
 
 void Voltage_Protect_Function()
 {
	static u8 cell_ovp_cnt = 0;
	static u8 cell_uvp_cnt = 0;
	//static u8 bat_ovp_cnt = 0;
	static u8 bat_uvp_cnt = 0;
	static u16 cell_err_cnt = 0;
	static u16 cell_dif_cnt = 0;
	//OVP
	if(Info.vcell_max > VCELL_OVP)
	{
		cell_ovp_cnt++;
		if(cell_ovp_cnt > GC_DELAY_2S)
		{
			cell_ovp_cnt = GC_DELAY_2S;
			protects.protect.chg_ovp_flag = 1;
			protects.protect.chg_full_flag = 1;
		}
	}
	else
	{
		if(protects.protect.chg_ovp_flag  == 1)
		{
			if(Info.vcell_max < VCELL_OVP_CLEAR)
			{
				if(cell_ovp_cnt > 0)
				{
					cell_ovp_cnt--;
				}
				else
				{
					protects.protect.chg_ovp_flag =0;
				}
			}
			else
			{
				cell_ovp_cnt =GC_DELAY_2S;
			}
		}
		else
		{
			cell_ovp_cnt = 0;
		}
	}
	//UVP cell
	if(Info.vcell_min < VCELL_UVP)
	{
		cell_uvp_cnt++;
		if(cell_uvp_cnt > GC_DELAY_4S)
		{
			cell_uvp_cnt = GC_DELAY_4S;
			protects.protect.dch_lvp2_flag = 1;
		}
	}
	else
	{
		if(protects.protect.dch_lvp2_flag  == 1)
		{
			if(Info.vcell_min > VCELL_UVP_CLEAR)
			{
				if(cell_uvp_cnt > 0)
				{
					cell_uvp_cnt--;
				}
				else
				{
					protects.protect.dch_lvp2_flag = 0;
				}
			}
			else
			{
				cell_uvp_cnt = GC_DELAY_4S;
			}
		}
		else
		{
			cell_uvp_cnt = 0;
		}
	}
	
	//UVP bat
	if(Info.afe.Voltage < VBAT_UVP)
	{
		bat_uvp_cnt++;
		if(bat_uvp_cnt > GC_DELAY_2S)
		{
			bat_uvp_cnt = GC_DELAY_2S;
			protects.protect.dch_lvp_flag = 1;
		}
	}
	else
	{
		if(protects.protect.dch_lvp_flag  == 1)
		{
			if(Info.afe.Voltage > VBAT_UVP_CLEAR)
			{
				if(bat_uvp_cnt > 0)
				{
					bat_uvp_cnt--;
				}
				else
				{
					protects.protect.dch_lvp_flag = 0;
				}
			}
			else
			{
				bat_uvp_cnt = GC_DELAY_2S;
			}
		}
		else
		{
			bat_uvp_cnt = 0;
		}
	}	
	
/*	 //OVP BAT
	
	if((Info.afe.Voltage > VBAT_FULL)&&(sys_flags.flag.adapter_connect_flag == 1))
	{
		bat_ovp_cnt++;
		if(bat_ovp_cnt > GC_DELAY_2S)
		{
			bat_ovp_cnt = GC_DELAY_2S;
			protects.protect.chg_full_flag = 1;
		}
	}
	else
	{
		if(protects.protect.chg_full_flag == 1)
		{
			if((Info.afe.Voltage < VBAT_FULL_CLEAR)&&(protects.protect.chg_ovp_flag == 0))
			{
				if(bat_ovp_cnt>0)
				{
					bat_ovp_cnt--;
				}
				else
				{
					protects.protect.chg_full_flag =0;
				}
			}
			else
			{
				bat_ovp_cnt = GC_DELAY_1S;
			}
		}
		else
		{
			bat_ovp_cnt =0;
		}
	}
*/	
	

	if(Info.vcell_min<VCELL_ERR)
	{
		cell_err_cnt++;
		if(cell_err_cnt > GC_DELAY_10S)
		{
			protects.protect.cell_low_2v_flag = 1;
		}
	}
	else
	{
		cell_err_cnt =0;
	}
	
	if((Info.vcell_max - Info.vcell_min) > VCELL_DEF)
	{
		cell_dif_cnt++;
		if(cell_dif_cnt > GC_DELAY_10S)
		{
			protects.protect.cell_dif_volt_flag = 1;
		}
	}
	else
	{
		cell_dif_cnt = 0;
	}
	
 }
 
 void Current_Protect_Function()
 {
	static u8 cur_dsg_ocp_cnt = 0;
	static u8 cur_dsg_start_cnt = 0;
	static u8 cur_dsg_ocp2_cnt = 0;
	static u8 cur_chg_ocp_cnt = 0;
	static u8 cur_chg_start_cnt = 0;
	static u8 cur_dsg_mos_err_cnt = 0;
		
	if(Info.afe.CurCadc > ICUR_CHG_STATE)
	{
		cur_chg_start_cnt++;
		if(cur_chg_start_cnt > GC_DELAY_1S)
		{
			cur_chg_start_cnt = GC_DELAY_1S;
			sys_flags.flag.chg_state_flag = 1;
		}
		
		
		if(Info.afe.CurCadc > ICUR_CHG_OCP)
		{
			cur_chg_ocp_cnt++;
			if(cur_chg_ocp_cnt > GC_DELAY_1S)
			{
				cur_chg_ocp_cnt = 0;
				protects.protect.chg_ocp_flag = 1;
			}
		}
		else
		{
			cur_chg_ocp_cnt = 0;
		}
	}
	else
	{
		cur_chg_ocp_cnt = 0;
		if(sys_flags.flag.chg_state_flag == 1)
		{
			if(cur_chg_start_cnt > 0)
			{
				cur_chg_start_cnt--;
			}
			else
			{
				sys_flags.flag.chg_state_flag = 0;
			}
		}
		else
		{
			cur_chg_start_cnt = 0;
		}
	}

	if(Info.afe.CurCadc > ICUR_DCH_STATE)
	{
		cur_dsg_start_cnt++;
		if(cur_dsg_start_cnt > GC_DELAY_1S)
		{
			cur_dsg_start_cnt = GC_DELAY_1S;
			sys_flags.flag.dch_state_flag = 1;
		}
				
		if(Info.afe.CurCadc > ICUR_DCH_OCP)
		{
			cur_dsg_ocp_cnt++;
			if(cur_dsg_ocp_cnt > GC_DELAY_1S)
			{
				cur_dsg_ocp_cnt = 0;
				protects.protect.dch_ocp_flag = 1;
			}
		}
		else
		{
			cur_dsg_ocp_cnt = 0;
		}
		
		if(Info.afe.CurCadc > ICUR_DCH_OCP2)
		{
			cur_dsg_ocp2_cnt++;
			if(cur_dsg_ocp2_cnt >GC_DELAY_05S)
			{
				cur_dsg_ocp2_cnt = 0;
				protects.protect.dch_ocp2_flag =1;
			}
		}
		else
		{
			cur_dsg_ocp2_cnt = 0;
		}
	}
	else
	{
		cur_dsg_ocp2_cnt =0;
		cur_dsg_ocp_cnt = 0;
		if(sys_flags.flag.dch_state_flag ==1)
		{
			if(cur_dsg_start_cnt > 0)
			{
				cur_dsg_start_cnt--;
			}
			else
			{
				sys_flags.flag.dch_state_flag =0;
			}
		}
		else
		{
			cur_dsg_start_cnt =0;
		}
	}	
	
	if (0) // �ŵ�MOS�ܹر�  ��⵽����
	{
		if(Info.afe.CurCadc > ICUR_DCH_MOS_ERR)
		{
			cur_dsg_mos_err_cnt++;
			if(cur_dsg_mos_err_cnt > GC_DELAY_05S)
			{
				cur_dsg_mos_err_cnt = 0;
				protects.protect.dch_mos_err_flag =1;
			}
		}
		else
		{
			cur_dsg_mos_err_cnt = 0;
		}
	}
	
}

 void Temperature_Protect_Function()
 {
	static u16 chg_otp_cnt =0;
	static u16 chg_ltp_cnt =0;
	static u16 dsg_otp_cnt =0;
	static u16 dsg_ltp_cnt =0;
	static u16 tp_open_cnt =0;
	static u16 tp_short_cnt =0;
	
	if(sys_flags.flag.adapter_connect_flag == 1)
	{
		if(Info.max_temp > NTC_CHG_OTP)
		{
			chg_otp_cnt++;
			if(chg_otp_cnt > GC_DELAY_4S)
			{
				chg_otp_cnt = GC_DELAY_4S;
				protects2.protect.chg_otp_flag = 1;
			}
		}
		else
		{
			if(protects2.protect.chg_otp_flag ==1)
			{
				if(Info.max_temp < NTC_CHG_OTP_CLEAR)
				{
					if(chg_otp_cnt > 0)
					{
						chg_otp_cnt--;
					}
					else
					{
						protects2.protect.chg_otp_flag = 0;
					}
				}
				else
				{
					chg_otp_cnt = GC_DELAY_4S;
				}
			}
			else
			{
				chg_otp_cnt =0;
			}
		}
		
		if(Info.min_temp < NTC_CHG_LTP)
		{
			chg_ltp_cnt++;
			if(chg_ltp_cnt > GC_DELAY_4S)
			{
				chg_ltp_cnt = GC_DELAY_4S;
				protects2.protect.chg_ltp_flag =1;
			}
		}
		else
		{
			if(protects2.protect.chg_ltp_flag ==1)
			{
				if(Info.min_temp > NTC_CHG_LTP_CLEAR)
				{
					if(chg_ltp_cnt > 0)
					{
						chg_ltp_cnt--;
					}
					else
					{
						protects2.protect.chg_ltp_flag = 0;
					}
				}
				else
				{
					chg_ltp_cnt = GC_DELAY_4S;
				}
			}
			else
			{
				chg_ltp_cnt =0;
			}
		}
	}
	else
	{
		protects2.protect.chg_otp_flag =0;
		chg_otp_cnt =0;
		protects2.protect.chg_ltp_flag =0;
		chg_ltp_cnt =0;
	}
	
	
	if(Info.max_temp > NTC_DCH_OTP)
	{
		dsg_otp_cnt++;
		if(dsg_otp_cnt > GC_DELAY_4S)
		{
			dsg_otp_cnt = GC_DELAY_4S;
			protects2.protect.dch_otp_flag = 1;
		}
	}
	else
	{
		if(protects2.protect.dch_otp_flag == 1)
		{
			if(Info.max_temp < NTC_DCH_OTP_CLEAR)
			{
				if(dsg_otp_cnt > 0)
				{
					dsg_otp_cnt--;
				}
				else
				{
					protects2.protect.dch_otp_flag = 0;
				}
			}
			else
			{
				dsg_otp_cnt = GC_DELAY_4S;
			}
		}
		else
		{
			dsg_otp_cnt =0;
		}
	}
	if(Info.min_temp < NTC_DCH_LTP)
	{
		dsg_ltp_cnt++;
		if(dsg_ltp_cnt > GC_DELAY_4S)
		{
			dsg_ltp_cnt = GC_DELAY_4S;
			protects2.protect.dch_ltp_flag = 1;
		}
	}
	else
	{
		if(protects2.protect.dch_ltp_flag == 1)
		{
			if(Info.min_temp > NTC_DCH_LTP_CLEAR)
			{
				if(dsg_ltp_cnt > 0)
				{
					dsg_ltp_cnt--;
				}
				else
				{
					protects2.protect.dch_ltp_flag = 0;
				}
			}
			else
			{
				dsg_ltp_cnt = GC_DELAY_4S;
			}
		}
		else
		{
			dsg_ltp_cnt = 0;
		}
	}
	
	if(Info.min_temp < NTC_OPEN)
	{
		tp_open_cnt++;
		if(tp_open_cnt > GC_DELAY_4S)
		{
			tp_open_cnt = GC_DELAY_4S;
			protects.protect.ntc_open_flag = 1;
		}
	}
	
	if(Info.max_temp > NTC_SHORT)
	{
		tp_short_cnt++;
		if(tp_short_cnt > GC_DELAY_4S)
		{
			tp_short_cnt = GC_DELAY_4S;
			protects.protect.ntc_short_flag = 1;
		}
	}	
	
 }
 
 
 void MOS_Control_Function()
 {
	if(sys_flags.flag.chg_en_flag ==0)
	{
		if((sys_flags.flag.adapter_connect_flag == 1)&&(protects2.protect.chg_ltp_flag ==0)
			&&(protects2.protect.chg_ltp_flag ==0)&&(protects.protect.chg_ocp_flag ==0)
			&&(protects.protect.chg_ovp_flag ==0)&&(protects.protect.chg_full_flag ==0))
		{
				//CHG_EN_ON();
			sys_flags.flag.chg_en_flag =1;
		}
	}
	else
	{
		if((sys_flags.flag.adapter_connect_flag == 0)||(protects2.protect.chg_ltp_flag ==1)
			||(protects2.protect.chg_ltp_flag ==1)||(protects.protect.chg_ocp_flag ==1)
			||(protects.protect.chg_ovp_flag ==1)||(protects.protect.chg_full_flag ==1))
		{
				//CHG_EN_OFF();
			sys_flags.flag.chg_en_flag =0;
		}
	}

	if(sys_flags.flag.dch_en_flag ==0)
	{
		if((sys_flags.flag.adapter_connect_flag == 0)&&(protects2.protect.dch_ltp_flag ==0)
			&&(protects2.protect.dch_ltp_flag ==0)&&(protects.protect.dch_ocp_flag ==0)
			&&(protects.protect.dch_lvp_flag ==0)&&(protects.protect.dch_ocp2_flag ==0))
		{
				//DSG_EN_ON();
			sys_flags.flag.dch_en_flag =1;
		}
	}
	else
	{
		if((sys_flags.flag.adapter_connect_flag == 1)||(protects2.protect.dch_ltp_flag ==1)
			||(protects2.protect.dch_ltp_flag ==1)||(protects.protect.dch_ocp_flag ==1)
			||(protects.protect.dch_lvp_flag ==1)||(protects.protect.dch_ocp2_flag ==1))
		{
				//DSG_EN_OFF();
			sys_flags.flag.dch_en_flag =0;
		}
	}
 }
 
 







 
 

