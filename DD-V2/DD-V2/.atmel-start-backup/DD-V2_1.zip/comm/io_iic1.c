/*********************************************************************************************************//**
 * @file    i2c_eeprom.c
 * @version $Rev:: 1736         $
 * @date    $Date:: 2017-08-25 #$
 * @brief   The source file of i2c_eeprom.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/

/* Includes ------------------------------------------------------------------------------------------------*/
#include "io_iic1.h"


/*
 * File:   IO_I2C.c
 * Author: AID
 *
 * ??IIC????
 * 
 * Created on 2016?9?22?, ??5:46
 */

/****************************************************************************
FUNCTION		: IIC_Init
DESCRIPTION		: ??IIC???
INPUT			: None
OUTPUT			: None
NOTICE			: ??IO????????,???????????????
DATE			: 2016/09/21
*****************************************************************************/
void IIC1_Init(void)
{	
	IIC1_SDA_OUT();
	IIC1_SCL_OUT();
	IIC1_SDA_L();
	IIC1_SCL_L();
	delay_ms(50);//??????IIC??,???IIC,?????
	IIC1_SCL_H();
	IIC1_SDA_H();
}

/****************************************************************************
FUNCTION		: IIC_Start
DESCRIPTION		: ??IIC??IIC????
INPUT			: None
OUTPUT			: None
NOTICE			: 
DATE			: 2016/09/21
*****************************************************************************/
void IIC1_Start(void)
{
	IIC1_SDA_OUT();//SDA??
	IIC1_SCL_H();	  	  
	IIC1_SDA_H();
	delay_us(10);
 	IIC1_SDA_L();//START:when CLK is high,DATA change form high to low 
	delay_us(10);
	IIC1_SCL_L();//??CLK??,??????
}	  
/****************************************************************************
FUNCTION		: IIC_Stop
DESCRIPTION		: ??IIC??IIC????
INPUT			: None
OUTPUT			: None
NOTICE			: 
DATE			: 2016/09/21
*****************************************************************************/
void IIC1_Stop(void)
{
	IIC1_SDA_OUT();//SDA??
	IIC1_SCL_L();
	IIC1_SDA_L();//STOP:when CLK is high DATA change form low to high
 	delay_us(10);
	IIC1_SCL_H();	
	IIC1_SDA_H();
	delay_us(10);							   	
}
/****************************************************************************
FUNCTION		: IIC_Wait_Ack
DESCRIPTION		: ??IIC??ACK??
INPUT			: None
OUTPUT			: None
NOTICE			: ????1??,0??
DATE			: 2016/09/21
*****************************************************************************/
u8 IIC1_Wait_Ack(void)
{
	u8 ucErrTime=0;
	IIC1_SDA_H();
  IIC1_SDA_IN();      //SDA???????   
	IIC1_SCL_H();	
    delay_us(5);	 
	while(IIC1_READ_SDA())
	{
		ucErrTime++;
		if(ucErrTime>250)
		{
			IIC1_Stop();
			return 1;
		}
	}
	IIC1_SCL_L();
	return 0;  
} 

/****************************************************************************
FUNCTION		: IIC_Ack
DESCRIPTION		: ??IIC??ACK????
INPUT			: None
OUTPUT			: None
NOTICE			: 
DATE			: 2016/09/21
*****************************************************************************/
void IIC1_Ack(void)
{
	IIC1_SCL_L();
	IIC1_SDA_OUT();//SDA??
	IIC1_SDA_L();//
	delay_us(5);
	IIC1_SCL_H();	
	delay_us(5);
	IIC1_SCL_L();
}
/****************************************************************************
FUNCTION		: IIC_NAck
DESCRIPTION		: ??IIC??NACK????
INPUT			: None
OUTPUT			: None
NOTICE			: 
DATE			: 2016/09/21
*****************************************************************************/
void IIC1_NAck(void)
{
	IIC1_SCL_L();
	IIC1_SDA_OUT();//SDA??
	IIC1_SDA_H();
	delay_us(5);
	IIC1_SCL_H();	
	delay_us(5);
	IIC1_SCL_L();
}					 				     
/****************************************************************************
FUNCTION		: IIC_Send_Byte
DESCRIPTION		: ??IIC??????
INPUT			: None
OUTPUT			: None
NOTICE			: 
DATE			: 2016/09/21
*****************************************************************************/
void IIC1_Send_Byte(u8 txd)
{                        
    u8 t;   
	IIC1_SDA_OUT();//SDA??
    IIC1_SCL_L();
    for(t=0;t<8;t++)
    {              
        if((txd&0x80)>>7)
        {
            IIC1_SDA_H();
        }
        else
        {
            IIC1_SDA_L();
        }
        txd<<=1; 	  
		delay_us(5);  
		IIC1_SCL_H();
		delay_us(5); 
		IIC1_SCL_L();
    }
    IIC1_Wait_Ack();	 
} 	    
/****************************************************************************
FUNCTION		: IIC_Read_Byte
DESCRIPTION		: ??IIC??????
INPUT			: None
OUTPUT			: None
NOTICE			: ??1???ACK?1??ACK,?0??NACK
DATE			: 2016/09/21
*****************************************************************************/
u8 IIC1_Read_Byte(unsigned char ack)
{
	unsigned char i,receive=0;
	IIC1_SDA_IN();//SDA??
	IIC1_SCL_L();
	delay_us(5);
    for(i=0;i<8;i++ )
	{
		IIC1_SCL_H();
        delay_us(5);
        receive<<=1;
        if(IIC1_READ_SDA())
        {
        	receive++;   
        }
		IIC1_SCL_L();
		delay_us(5); 
    }					 
    if (!ack)
        IIC1_NAck();
    else
        IIC1_Ack(); 
    return receive;
}






























/**
  * @}
  */


/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */
