/*
 * i2c_sd2058.c
 *
 * Created: 2020/5/15 15:55:32
 *  Author: chenjiawei
 */ 

#include "comm/i2c_sd2058.h"

SD2058_VAL sd2058_val;

void I2C1_SendBytes(unsigned char targer, unsigned char *DataBuffer, unsigned char ByteCount)
{
	uint8_t i;
	IIC1_Start();
	IIC1_Send_Byte(SD2058_ADDRESS_W);
	IIC1_Send_Byte(targer);
	for(i=0;i<ByteCount;i++)
	{
		IIC1_Send_Byte(*DataBuffer);
		DataBuffer++;
	}
	IIC1_Stop();
}

void I2C1_ReadBytes(unsigned char targer, unsigned char *DataBuffer, unsigned int ExpectedByteNumber)
{
	unsigned char i = 0;
	IIC1_Start();
	IIC1_Send_Byte(SD2058_ADDRESS_W);
	IIC1_Send_Byte(targer);
	delay_us(20);
	IIC1_Start();
	IIC1_Send_Byte(SD2058_ADDRESS_R);
	for(i=0;i<ExpectedByteNumber-1;i++)
	{
		*DataBuffer =IIC1_Read_Byte(ACK);
		DataBuffer++;
	}
	*DataBuffer =IIC1_Read_Byte(NACK);
	IIC1_Stop();
}

void SD2058_Time_Init(void)
{
	//��ʱ�޳�ʼ��
}

void SD2058_Rtc_Read_Time(SD2058_VAL *p)
{
    unsigned char temp[10] ;
    I2C1_ReadBytes( 0 , temp , 7); //reg address first is 0,buff is temp,length of reg is 7

	p->seconds = bcd2bin(temp[0] & SD2058_SECONDS_MASK);
	p->minutes = bcd2bin(temp[1] & SD2058_MINUTES_MASK);
	p->hours = bcd2bin(temp[2] & SD2058_HOURS_MASK);
	p->wday = bcd2bin(temp[3]);
	p->date = bcd2bin(temp[4]);
	p->month = bcd2bin(temp[5]);
	p->years= bcd2bin(temp[6]);

}


void SD2058_Rtc_Write_Time(SD2058_VAL *p)
{
    unsigned char temp[10] ;
    temp[0] = bin2bcd(p->seconds);
    temp[1] = bin2bcd(p->minutes);
    temp[2] = bin2bcd(p->hours);
    temp[3] = bin2bcd(p->wday);
    temp[4] = bin2bcd(p->date);
    temp[5] = bin2bcd(p->month);
    temp[6] = bin2bcd(p->years);
    I2C1_SendBytes( 0 , temp , 7);

}


/**
  * @brief  This function is bcd2bin.
  * @param  unsigned char val
  * @retval None
  */
  
unsigned char bcd2bin(unsigned char val)
{
    return (val & 0x0f) + (val >> 4) * 10;
}
 
/**
  * @brief  This function is bin2bcd.
  * @param  unsigned char val
  * @retval None
  */
  
unsigned char bin2bcd(unsigned char val)
{
    return ((val / 10) << 4) + val % 10;
}

