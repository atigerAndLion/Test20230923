/*
 * user_bms.c
 *
 * Created: 2020/5/15 14:41:48
 *  Author: chenjiawei
 */ 
#include "i2c_sh367309.h"
#include "user_bms.h"


u16 vin_val;

uint8_t chg_retry_cnt = 0;
uint8_t dsg_retry_cnt = 0;
uint8_t dsg2_retry_cnt = 0;
uint16_t stick_30s_cnt = 0;//Ԥ�ŵ�30S ����

/*
 * 103AT volt
 * 3.3V--10K--103AT---GND
 * REF 3.3V
 * ADC 10bit
 */
const uint16_t TEMP_VOLT_TABLE[MCU_TEMP_DEGREE_RANGE] =  
{
	3909,3899,3888,3877,3865,3853,3840,3826,3812,3798,
	3783,3767,3750,3733,3716,3698,3679,3659,3639,3618,
	3597,3578,3558,3537,3516,3494,3465,3436,3405,3374,
	3343,3314,3284,3253,3222,3191,3156,3121,3085,3049,
	3013,2977,2941,2905,2868,2830,2794,2757,2719,2681,
	2643,2594,2546,2499,2454,2409,2379,2347,2314,2279,
	2244,2204,2165,2126,2087,2048,2010,1972,1934,1897,
	1860,1823,1787,1750,1714,1679,1644,1609,1575,1542,
	1509,1476,1444,1412,1380,1349,1319,1289,1260,1231,
	1203,1176,1149,1123,1098,1073,1048,1023,999,976,
	953,930,908,887,866,845,825,805,786,767,
	749,732,714,698,682,666,649,634,618,603,
	589,574,560,546,532,519,507,496,485,474,
	464,453,442,432,422,412,402,393,384,375,
	367,359,351,343,336,328,321,314,307,300,
	293,287,281,275,269,263,257,251,246,240,
	235,230,225,220,215,210
};

/****************************************************************************
FUNCTION		: AFE_Update_Function
DESCRIPTION		: ��AFE��������
INPUT			: None
OUTPUT			: None
*****************************************************************************/

 void AFE_Update_Function()
 {
	 UpdateDataFromSH367309();
 }
 
 /****************************************************************************
 FUNCTION		: State_Change_Function
 DESCRIPTION	: ����ϵͳ״̬����
 INPUT			: None
 OUTPUT			: None
 *****************************************************************************/

 void State_Change_Function()
 {
	Adapter_Function();
	Voltage_Protect_Function();
	Current_Protect_Function();
	Temperature_Protect_Function();
	Protect_Retry_Function();
 }
 
 /****************************************************************************
 FUNCTION		: ADC_Function
 DESCRIPTION	: MCU �Դ�ADC �ɼ���ѹ��������
 INPUT			: None
 OUTPUT			: None
 *****************************************************************************/
 
 void ADC_Function()
 {
	 uint8_t buffer[2]={0};
	 uint16_t ad_val=0;
	 
	 
	 
	 
	
	 // GET WT1 WT2
	 adc_sync_enable_channel(&ADC_0, 0);
	 adc_sync_enable_channel(&ADC_1, 0);
	 
	 adc_sync_set_inputs(&ADC_0,AD_WT2_ADC0_CHANNEL,0x18,0);
	 adc_sync_read_channel(&ADC_0, AD_WT2_ADC0_CHANNEL, buffer, 2);

	 adc_sync_set_inputs(&ADC_1,AD_WT1_ADC1_CHANNEL,0x18,0);
	 adc_sync_read_channel(&ADC_1, AD_WT1_ADC1_CHANNEL, buffer, 2);

	 // GET AD BAT	
	 adc_sync_set_inputs(&ADC_0,AD_BAT_ADC0_CHANNEL,0x18,0);
	 adc_sync_read_channel(&ADC_0, AD_BAT_ADC0_CHANNEL, buffer, 2);
	 ad_val = buffer[1] << 8 | buffer[0];
	 ad_val = ad_val*3300 /4096 *61; //�����ѹ1/31
	 
	 // GET AD RT4 RT5
	 adc_sync_set_inputs(&ADC_0,AD_RT4_ADC0_CHANNEL,0x18,0);
	 adc_sync_read_channel(&ADC_0, AD_RT4_ADC0_CHANNEL, buffer, 2);
	 ad_val = buffer[1] << 8 | buffer[0];
	 Info.afe.Temperature4 = Find_MCU_Temp(ad_val) - MCU_TEMP_OFFSET_VAL;
	 
	 adc_sync_set_inputs(&ADC_0,AD_RT5_ADC0_CHANNEL,0x18,0);
	 adc_sync_read_channel(&ADC_0, AD_RT5_ADC0_CHANNEL, buffer, 2);
	 ad_val = buffer[1] << 8 | buffer[0];
	 Info.g_NTC1_DSGFET_T = Find_MCU_Temp(ad_val) - MCU_TEMP_OFFSET_VAL;
	 Info.g_NTC2_CHGFET_T = Info.g_NTC1_DSGFET_T;
	 
	 RT_ON_OFF();
		  
	 // GET AD P+
	 adc_sync_set_inputs(&ADC_0,AD_PP_ADC0_CHANNEL,0x18,0);
	 adc_sync_read_channel(&ADC_0, AD_PP_ADC0_CHANNEL, buffer, 2);
	 ad_val = buffer[1] << 8 | buffer[0];
	 ad_val = ad_val*3300 /4096 *31;//�����ѹ1/31
	 
	 // GET AD 5V
	 VCC_EN_ON();
	 adc_sync_set_inputs(&ADC_1,AD_5V_ADC1_CHANNEL,0x18,0);
	 adc_sync_read_channel(&ADC_1, AD_5V_ADC1_CHANNEL, buffer, 2);
	 ad_val = buffer[1] << 8 | buffer[0];
	 ad_val = ad_val*3300 /4096 *3; //�����ѹ1/3
 }
 
 /****************************************************************************
 FUNCTION		: Adapter_Function
 DESCRIPTION	: ���������� ��������
 INPUT			: None
 OUTPUT			: None
 *****************************************************************************/
 
 void Adapter_Function()
 {
	static u8 adapter_connect_cnt = 0;
	static u8 id_connect_cnt = 0;
	
	// ID ��λ���
	if (DET_READ())
	{
		//ID δ�����ƽ
		if (sys_flags.flag.sys_id_connect_flag == 1)
		{
			id_connect_cnt--;
			if (id_connect_cnt == 0)
			{
				//ID�γ�
				if (sys_flags.flag.dch_state_flag == 1) //�����ʱ��������300mA ��Ϊ�쳣�γ�״̬
				{
					sys_flags.flag.sys_id_error_flag = 1;
				}
				sys_flags.flag.sys_id_connect_flag = 0;
				// ID�Ƴ� �ָ��ŵ����һ�� �������� ����������
				protects.protect.dch_ocp_flag = 0;
				protects.protect.dch_ocp2_flag = 0;
				protects.protect.chg_ocp_flag = 0;
				chg_retry_cnt = 0; //���ó���������
			}
		} 
		else
		{
			id_connect_cnt = 0;
		}
	} 
	else
	{
		//ID �����ƽ
		id_connect_cnt++;
		if (id_connect_cnt > GC_DELAY_2S)
		{
			id_connect_cnt = GC_DELAY_2S;
			if (sys_flags.flag.sys_id_connect_flag == 0)
			{
				sys_flags.flag.sys_id_connect_flag = 1; //��λID
				sys_flags.flag.open_dch_30s_end_flag =0; //���Ԥ������ɱ�־λ
				stick_30s_cnt = 0;
			}
			
			sys_flags.flag.sys_id_error_flag = 0 ; //ID���� ���ID�쳣״̬
			//ID����
		}
	}
	
	//ID��λ Ԥ�ŵ翪ʼ
	if (sys_flags.flag.sys_id_connect_flag == 1 && sys_flags.flag.open_dch_30s_end_flag == 0)
	{
		stick_30s_cnt++; // �ݷ�����  ���Ƕ�ʱ�����Ӽ���
		if(stick_30s_cnt > GC_DELAY_30S)
		{
			stick_30s_cnt = GC_DELAY_30S;
			sys_flags.flag.open_dch_30s_end_flag = 1; // Ԥ�ŵ����
			if(protects.protect.forbidden_output == 1)
			{
				protects.protect.forbidden_output = 0;
			}
		}
	} 
	else
	{   
		//Ԥ�ŵ�û����  ID�Ƴ�  ֱ����λԤ�ŵ�
		if (sys_flags.flag.sys_id_connect_flag == 0 && sys_flags.flag.open_dch_30s_end_flag == 0)
		{
			sys_flags.flag.open_dch_30s_end_flag = 1;
			if(protects.protect.forbidden_output == 1)
			{
				protects.protect.forbidden_output = 0;
			}
		}
	}
	
	
	//if(sys_flags.flag.adapter_int_flag == 1)
	//{
		//sys_flags.flag.adapter_connect_flag =1;
		//sys_flags.flag.adapter_int_flag =0;
		//adapter_connect_cnt = GC_DELAY_1S;
	//}
	
	
	if(vin_val > VPACK_CONNECT && sys_flags.flag.sys_id_connect_flag == 1)
	{
		adapter_connect_cnt++;
		if(adapter_connect_cnt > GC_DELAY_2S)
		{
			adapter_connect_cnt = GC_DELAY_2S;
			sys_flags.flag.adapter_connect_flag =1;
		}
	}
	else
	{
		if(sys_flags.flag.adapter_connect_flag ==1)
		{
			if(adapter_connect_cnt < VPACK_NCONT)
			{
				if(adapter_connect_cnt>0)
				{
					adapter_connect_cnt--;
				}
				else
				{
					sys_flags.flag.adapter_connect_flag =0;
				}
			}
			else
			{
				adapter_connect_cnt = GC_DELAY_2S;
			}
		}
		else
		{
			adapter_connect_cnt = 0;
		}
	}
 }
 
 /****************************************************************************
 FUNCTION		: Voltage_Protect_Function
 DESCRIPTION	: ��ѹ Ƿѹ�ȵ�ѹ��� ��������
 INPUT			: None
 OUTPUT			: None
 *****************************************************************************/
 
 void Voltage_Protect_Function()
 {
	static u8 cell_ovp_cnt = 0;
	static u8 cell_uvp_cnt = 0;
	static u8 bat_ovp_cnt = 0;
	static u8 bat_uvp_cnt = 0;
	static u16 cell_err_cnt = 0;
	static u16 cell_dif_cnt = 0;
	//OVP
	if(Info.vcell_max > VCELL_OVP)
	{
		cell_ovp_cnt++;
		if(cell_ovp_cnt > GC_DELAY_2S)
		{
			cell_ovp_cnt = GC_DELAY_2S;
			protects.protect.chg_ovp_flag = 1;
			protects.protect.chg_full_flag = 1;
		}
	}
	else
	{
		if(protects.protect.chg_ovp_flag  == 1)
		{
			if(Info.vcell_max < VCELL_OVP_CLEAR)
			{
				if(cell_ovp_cnt > 0)
				{
					cell_ovp_cnt--;
				}
				else
				{
					protects.protect.chg_ovp_flag =0;
				}
			}
			else
			{
				cell_ovp_cnt =GC_DELAY_2S;
			}
		}
		else
		{
			cell_ovp_cnt = 0;
		}
	}
	//UVP cell
	if(Info.vcell_min < VCELL_UVP)
	{
		cell_uvp_cnt++;
		if(cell_uvp_cnt > GC_DELAY_2S)
		{
			cell_uvp_cnt = GC_DELAY_2S;
			protects.protect.dch_lvp2_flag = 1;
		}
	}
	else
	{
		if(protects.protect.dch_lvp2_flag  == 1)
		{
			if(Info.vcell_min > VCELL_UVP_CLEAR)
			{
				if(cell_uvp_cnt > 0)
				{
					cell_uvp_cnt--;
				}
				else
				{
					protects.protect.dch_lvp2_flag = 0;
				}
			}
			else
			{
				cell_uvp_cnt = GC_DELAY_2S;
			}
		}
		else
		{
			cell_uvp_cnt = 0;
		}
	}
	
	//UVP bat
	if(Info.afe.Voltage < VBAT_UVP)
	{
		bat_uvp_cnt++;
		if(bat_uvp_cnt > GC_DELAY_2S)
		{
			bat_uvp_cnt = GC_DELAY_2S;
			protects.protect.dch_lvp_flag = 1;
		}
	}
	else
	{
		if(protects.protect.dch_lvp_flag  == 1)
		{
			if(Info.afe.Voltage > VBAT_UVP_CLEAR)
			{
				if(bat_uvp_cnt > 0)
				{
					bat_uvp_cnt--;
				}
				else
				{
					protects.protect.dch_lvp_flag = 0;
				}
			}
			else
			{
				bat_uvp_cnt = GC_DELAY_2S;
			}
		}
		else
		{
			bat_uvp_cnt = 0;
		}
	}	
	
	 //OVP BAT
	
	if((Info.afe.Voltage > VBAT_FULL)&&(sys_flags.flag.adapter_connect_flag == 1))
	{
		bat_ovp_cnt++;
		if(bat_ovp_cnt > GC_DELAY_4S)
		{
			bat_ovp_cnt = GC_DELAY_4S;
			protects.protect.chg_full_flag = 1;
		}
	}
	else
	{
		if(protects.protect.chg_full_flag == 1)
		{
			if((Info.afe.Voltage < VBAT_FULL_CLEAR)&&(protects.protect.chg_ovp_flag == 0))
			{
				if(bat_ovp_cnt>0)
				{
					bat_ovp_cnt--;
				}
				else
				{
					protects.protect.chg_full_flag =0;
				}
			}
			else
			{
				bat_ovp_cnt = GC_DELAY_1S;
			}
		}
		else
		{
			bat_ovp_cnt =0;
		}
	}

	

	if(Info.vcell_min<VCELL_ERR)
	{
		cell_err_cnt++;
		if(cell_err_cnt > GC_DELAY_10S)
		{
			protects.protect.cell_low_2v_flag = 1;
		}
	}
	else
	{
		cell_err_cnt =0;
	}
	
	if((Info.vcell_max - Info.vcell_min) > VCELL_DEF)
	{
		cell_dif_cnt++;
		if(cell_dif_cnt > GC_DELAY_10S)
		{
			protects.protect.cell_dif_volt_flag = 1;
		}
	}
	else
	{
		cell_dif_cnt = 0;
	}
	
 }
 
 /****************************************************************************
 FUNCTION		: Current_Protect_Function
 DESCRIPTION	: ���� ��·�ȵ������ ��������
 INPUT			: None
 OUTPUT			: None
 *****************************************************************************/
 
 void Current_Protect_Function()
 {
	static u8 cur_dsg_ocp_cnt = 0;
	static u8 cur_dsg_start_cnt = 0;
	static u8 cur_dsg_ocp2_cnt = 0;
	static u8 cur_chg_ocp_cnt = 0;
	static u8 cur_chg_start_cnt = 0;
	static u8 cur_dsg_mos_err_cnt = 0;
	static u8 cur_chg_mos_err_cnt = 0;
		
	if(Info.afe.CurCadc > ICUR_CHG_STATE)
	{
		cur_chg_start_cnt++;
		if(cur_chg_start_cnt > GC_DELAY_2S)
		{
			cur_chg_start_cnt = GC_DELAY_2S;
			sys_flags.flag.chg_state_flag = 1;
			if (sys_flags.flag.sys_comm_open_dch_flag ==0) //�г����� ͨ��δ�����
			{
				sys_flags.flag.adapter_connect_flag = 1;
				sys_flags.flag.open_dch_30s_end_flag = 1;
				if(protects.protect.forbidden_output == 1)
				{
					protects.protect.forbidden_output = 0;
				}
			}
		}
		
		
		if(Info.afe.CurCadc > ICUR_CHG_OCP)
		{
			cur_chg_ocp_cnt++;
			if(cur_chg_ocp_cnt > GC_DELAY_4S)
			{
				cur_chg_ocp_cnt = 0;
				protects.protect.chg_ocp_flag = 1;
				sys_flags.flag.open_dch_30s_end_flag = 1;
			}
		}
		else
		{
			cur_chg_ocp_cnt = 0;
		}
	}
	else
	{
		cur_chg_ocp_cnt = 0;
		if(sys_flags.flag.chg_state_flag == 1)
		{
			if(cur_chg_start_cnt > 0)
			{
				cur_chg_start_cnt--;
			}
			else
			{
				sys_flags.flag.chg_state_flag = 0;
			}
		}
		else
		{
			cur_chg_start_cnt = 0;
		}
	}

	if(Info.afe.CurCadc < ICUR_DCH_STATE)
	{
		cur_dsg_start_cnt++;
		if(cur_dsg_start_cnt > GC_DELAY_2S)
		{
			cur_dsg_start_cnt = GC_DELAY_2S;
			sys_flags.flag.dch_state_flag = 1;
		}
				
		if(Info.afe.CurCadc < ICUR_DCH_OCP)
		{
			cur_dsg_ocp_cnt++;
			if(cur_dsg_ocp_cnt > GC_DELAY_6S)
			{
				cur_dsg_ocp_cnt = 0;
				protects.protect.dch_ocp_flag = 1;
			}
		}
		else
		{
			cur_dsg_ocp_cnt = 0;
		}
		
		if(Info.afe.CurCadc < ICUR_DCH_OCP2)
		{
			cur_dsg_ocp2_cnt++;
			if(cur_dsg_ocp2_cnt >GC_DELAY_02S)
			{
				cur_dsg_ocp2_cnt = 0;
				protects.protect.dch_ocp2_flag =1;
			}
		}
		else
		{
			cur_dsg_ocp2_cnt = 0;
		}
	}
	else
	{
		cur_dsg_ocp2_cnt =0;
		cur_dsg_ocp_cnt = 0;
		if(sys_flags.flag.dch_state_flag ==1)
		{
			if(cur_dsg_start_cnt > 0)
			{
				cur_dsg_start_cnt--;
			}
			else
			{
				sys_flags.flag.dch_state_flag =0;
			}
		}
		else
		{
			cur_dsg_start_cnt =0;
		}
	}	
	
	if (sys_flags.flag.dch_en_flag == 0) // �ŵ�MOS�ܹر�  ��⵽����
	{
		if(Info.afe.CurCadc < ICUR_DCH_MOS_ERR)
		{
			cur_dsg_mos_err_cnt++;
			if(cur_dsg_mos_err_cnt > GC_DELAY_05S)
			{
				cur_dsg_mos_err_cnt = 0;
				protects.protect.dch_mos_err_flag =1;
			}
		}
		else
		{
			cur_dsg_mos_err_cnt = 0;
		}
	}
	
	if (sys_flags.flag.chg_en_flag == 0) // ���MOS�ܹر�  ��⵽����
	{
		if(Info.afe.CurCadc > ICUR_CHG_MOS_ERR)
		{
			cur_chg_mos_err_cnt++;
			if(cur_chg_mos_err_cnt > GC_DELAY_05S)
			{
				cur_chg_mos_err_cnt = 0;
				protects.protect.chg_mos_err_flag =1;
			}
		}
		else
		{
			cur_chg_mos_err_cnt = 0;
		}
	}
	
	if (AFE.BSTATUS1.Bit.SC	== 1)
	{
		protects.protect.dch_scd_flag = 1;
		sys_flags.flag.dch_state_flag =0;
		sys_flags.flag.sys_comm_open_dch_flag =0;
	}
	else
	{
		protects.protect.dch_scd_flag = 0;
	}
	
}

 /****************************************************************************
 FUNCTION		: Temperature_Protect_Function
 DESCRIPTION	: ���� ���µ��¶���� ��������
 INPUT			: None
 OUTPUT			: None
 *****************************************************************************/
 
 void Temperature_Protect_Function()
 {
	static u16 chg_otp_cnt =0;
	static u16 chg_ltp_cnt =0;
	static u16 dsg_otp_cnt =0;
	static u16 dsg_ltp_cnt =0;
	static u16 tp_open_cnt =0;
	static u16 tp_short_cnt =0;
	
	if(sys_flags.flag.adapter_connect_flag == 1)
	{
		if(Info.max_temp > NTC_CHG_OTP)
		{
			chg_otp_cnt++;
			if(chg_otp_cnt > GC_DELAY_5S)
			{
				chg_otp_cnt = GC_DELAY_5S;
				protects2.protect.chg_otp_flag = 1;
			}
		}
		else
		{
			if(protects2.protect.chg_otp_flag ==1)
			{
				if(Info.max_temp < NTC_CHG_OTP_CLEAR)
				{
					if(chg_otp_cnt > 0)
					{
						chg_otp_cnt--;
					}
					else
					{
						protects2.protect.chg_otp_flag = 0;
					}
				}
				else
				{
					chg_otp_cnt = GC_DELAY_5S;
				}
			}
			else
			{
				chg_otp_cnt =0;
			}
		}
		
		if(Info.min_temp < NTC_CHG_LTP)
		{
			chg_ltp_cnt++;
			if(chg_ltp_cnt > GC_DELAY_5S)
			{
				chg_ltp_cnt = GC_DELAY_5S;
				protects2.protect.chg_ltp_flag =1;
			}
		}
		else
		{
			if(protects2.protect.chg_ltp_flag ==1)
			{
				if(Info.min_temp > NTC_CHG_LTP_CLEAR)
				{
					if(chg_ltp_cnt > 0)
					{
						chg_ltp_cnt--;
					}
					else
					{
						protects2.protect.chg_ltp_flag = 0;
					}
				}
				else
				{
					chg_ltp_cnt = GC_DELAY_5S;
				}
			}
			else
			{
				chg_ltp_cnt =0;
			}
		}
	}
	else
	{
		protects2.protect.chg_otp_flag =0;
		chg_otp_cnt =0;
		protects2.protect.chg_ltp_flag =0;
		chg_ltp_cnt =0;
	}
	
	
	if(Info.max_temp > NTC_DCH_OTP)
	{
		dsg_otp_cnt++;
		if(dsg_otp_cnt > GC_DELAY_5S)
		{
			dsg_otp_cnt = GC_DELAY_5S;
			protects2.protect.dch_otp_flag = 1;
		}
	}
	else
	{
		if(protects2.protect.dch_otp_flag == 1)
		{
			if(Info.max_temp < NTC_DCH_OTP_CLEAR)
			{
				if(dsg_otp_cnt > 0)
				{
					dsg_otp_cnt--;
				}
				else
				{
					protects2.protect.dch_otp_flag = 0;
				}
			}
			else
			{
				dsg_otp_cnt = GC_DELAY_5S;
			}
		}
		else
		{
			dsg_otp_cnt =0;
		}
	}
	if(Info.min_temp < NTC_DCH_LTP)
	{
		dsg_ltp_cnt++;
		if(dsg_ltp_cnt > GC_DELAY_5S)
		{
			dsg_ltp_cnt = GC_DELAY_5S;
			protects2.protect.dch_ltp_flag = 1;
		}
	}
	else
	{
		if(protects2.protect.dch_ltp_flag == 1)
		{
			if(Info.min_temp > NTC_DCH_LTP_CLEAR)
			{
				if(dsg_ltp_cnt > 0)
				{
					dsg_ltp_cnt--;
				}
				else
				{
					protects2.protect.dch_ltp_flag = 0;
				}
			}
			else
			{
				dsg_ltp_cnt = GC_DELAY_5S;
			}
		}
		else
		{
			dsg_ltp_cnt = 0;
		}
	}
	
	if(Info.min_temp < NTC_OPEN)
	{
		tp_open_cnt++;
		if(tp_open_cnt > GC_DELAY_4S)
		{
			tp_open_cnt = GC_DELAY_4S;
			protects.protect.ntc_open_flag = 1;
		}
	}
	
	if(Info.max_temp > NTC_SHORT)
	{
		tp_short_cnt++;
		if(tp_short_cnt > GC_DELAY_4S)
		{
			tp_short_cnt = GC_DELAY_4S;
			protects.protect.ntc_short_flag = 1;
		}
	}	
	
 }
 
  /****************************************************************************
 FUNCTION		: MOS_Control_Function
 DESCRIPTION	: ��� �ŵ� MOS ���ƺ���
 INPUT			: None
 OUTPUT			: None
 *****************************************************************************/
 
 void MOS_Control_Function()
 {
	//����MOS��״̬
	if (AFE.BSTATUS3.Bit.CHG_FET == 1)
	{
		sys_flags.flag.chg_en_flag = 1;
	}
	else
	{
		sys_flags.flag.chg_en_flag = 0;
	}
	
	if (AFE.BSTATUS3.Bit.DSG_FET == 1)
	{
		sys_flags.flag.dch_en_flag = 1;
	}
	else
	{
		sys_flags.flag.dch_en_flag = 0;
	}
	 
	if(sys_flags.flag.chg_en_flag == 0)
	{
		if(
			(sys_flags.flag.adapter_connect_flag == 1)&&
			(protects.protect.chg_full_flag ==0)&&
			(protects.protect.chg_ocp_flag ==0)&&
			(protects.protect.chg_ovp_flag ==0)&&
			(protects.protect.cell_dif_volt_flag ==0)&&
			(protects.protect.cell_low_2v_flag ==0)&&
			(protects2.protect.chg_ltp_flag ==0)&&
			(protects2.protect.chg_ltp2_flag ==0)&&
			(protects2.protect.chg_otp_flag ==0)&&
			(protects2.protect.chg_otp2_flag ==0)&&
			(protects2.protect.dch_ltp_flag ==0)&&
			(protects2.protect.dch_ltp2_flag ==0)&&
			(protects2.protect.dch_otp_flag ==0)&&
			(protects2.protect.dch_otp2_flag ==0)			
		  )
		{
				//CHG_EN_ON();
			//sys_flags.flag.chg_en_flag =1;
			if (sys_flags.flag.adapter_connect_flag == 1 && sys_flags.flag.chg_state_flag == 1)
			{
				// ������ �� �ŵ��
				Dsg_Control(OPEN_MOS);
				Chg_Control(OPEN_MOS);
			} 
			else
			{
				// 
				if((sys_flags.flag.sys_comm_open_dch_flag ==1)&&(sys_flags.flag.dch_en_flag ==1))//ͨ�ſ��ŵ�
				{
					Chg_Control(OPEN_MOS);
				}
				if((sys_flags.flag.sys_id_connect_flag ==1)&&(sys_flags.flag.open_dch_30s_end_flag ==0)&&(sys_flags.flag.dch_en_flag == 1))//30Sǿ�ƿ��ŵ�
				{
					Chg_Control(OPEN_MOS);
				}
			}
		}
	}
	else
	{
		if(
			(protects.protect.chg_full_flag ==1)||
			(protects.protect.chg_ocp_flag ==1)||		
			(protects.protect.chg_ovp_flag ==1)||
			(protects.protect.cell_dif_volt_flag ==1)||
			(protects.protect.cell_low_2v_flag ==1)||		
			(sys_flags.flag.adapter_connect_flag == 0)||
			(sys_flags.flag.sys_id_connect_flag == 0)||
			(protects2.protect.chg_otp_flag ==1)||
			(protects2.protect.chg_otp2_flag ==1)||
			(protects2.protect.chg_ltp_flag ==1)||
			(protects2.protect.chg_ltp2_flag ==1)||
			(protects2.protect.dch_otp_flag ==1)||
			(protects2.protect.dch_otp2_flag ==1)||
			(protects2.protect.dch_ltp_flag ==1)||
			(protects2.protect.dch_ltp2_flag ==1)

		  )
		{
				//CHG_EN_OFF();
			//sys_flags.flag.chg_en_flag =0;
			if (sys_flags.flag.sys_id_connect_flag == 1)
			{
				if (sys_flags.flag.open_dch_30s_end_flag == 1)//30��ǿ�Ʒŵ�
				{
					if (sys_flags.flag.sys_comm_open_dch_flag == 0) //Ԥ�ŵ�û���յ�ͨ�ſ��ŵ�
					{
						Chg_Control(CLOSE_MOS);
					}
					else
					{
						if((protects2.protect.dch_otp2_flag == 1) || (protects2.protect.dch_otp_flag == 1) ||
						(protects2.protect.dch_ltp2_flag == 1) || (protects2.protect.dch_ltp_flag == 1))
						{
							Chg_Control(CLOSE_MOS);
						}
					}
				}
				
				if(
					(protects.protect.cell_low_2v_flag == 1)||
					(protects.protect.dch_scd_flag ==1)||
					(protects.protect.chg_full_flag ==1)||
					(protects.protect.chg_ovp_flag == 1)||
					(protects.protect.chg_ocp_flag == 1)
				  )
				{
					Chg_Control(CLOSE_MOS);
				}

			} 
			else
			{
				Chg_Control(CLOSE_MOS);//�رճ���
			}
		}
	}

	if(sys_flags.flag.dch_en_flag ==0)
	{
		if(
			//(protects.protect.dch_empty_flag ==0)&&
			(protects.protect.dch_scd_flag ==0)&&
			(protects.protect.dch_ocp_flag ==0)&&
			(protects.protect.dch_ocp2_flag ==0)&&
			(protects.protect.dch_lvp_flag ==0)&&
			(protects.protect.cell_low_2v_flag ==0)&&
			(protects.protect.cell_dif_volt_flag ==0)&&
			(protects2.protect.dch_otp_flag ==0)&&
			(protects2.protect.dch_otp2_flag ==0)&&
			(protects2.protect.dch_ltp_flag ==0)&&
			(protects2.protect.dch_ltp2_flag ==0)			
		  )
		{
				//DSG_EN_ON();
			if(sys_flags.flag.sys_comm_open_dch_flag ==0 )
			{
				if ((sys_flags.flag.sys_id_connect_flag ==1)&&(sys_flags.flag.open_dch_30s_end_flag ==0)) //id���� && 30��Ԥ�ŵ�δ����
				{
					Chg_Control(OPEN_MOS);
					Dsg_Control(OPEN_MOS);
					protects.protect.chg_full_flag =0;
					protects.protect.chg_ocp_flag =0;
					protects.protect.chg_ovp_flag =0;	
				}
			}
			else
			{
				if (sys_flags.flag.sys_id_connect_flag == 1)
				{
					Chg_Control(OPEN_MOS);
					Dsg_Control(OPEN_MOS);
					//�򿪳��
					//�򿪷ŵ�
				}
			}
			//sys_flags.flag.dch_en_flag =1;

			
			if (sys_flags.flag.chg_state_flag == 1 && sys_flags.flag.adapter_connect_flag == 1)
			{
				if (sys_flags.flag.sys_id_connect_flag == 1)
				{
					Dsg_Control(OPEN_MOS);
					//�򿪳��
				}
			}
		}
	}
	else
	{
		if(
			(sys_flags.flag.sys_id_connect_flag ==0)||
			//(protects.protect.dch_empty_flag)||
			(protects.protect.dch_scd_flag ==1)||
			(protects.protect.dch_lvp_flag ==1)||
			(protects.protect.dch_ocp_flag ==1)||
			(protects.protect.cell_dif_volt_flag ==1)||
			(protects.protect.cell_low_2v_flag ==1)||
			(protects.protect.dch_ocp2_flag ==1)||
			(protects2.protect.dch_ltp2_flag ==1)||
			(protects2.protect.dch_otp2_flag ==1)||			
			(protects2.protect.dch_ltp_flag ==1)||
			(protects2.protect.dch_otp_flag ==1)
			
		  )
		{
				//DSG_EN_OFF();
			//sys_flags.flag.dch_en_flag =0;
			if ((sys_flags.flag.sys_id_connect_flag ==1)&&(sys_flags.flag.open_dch_30s_end_flag ==0))// ID���� && Ԥ�ŵ�30Sδ����
			{
				//30Sǿ�ƿ����  �����¶� ѹ��ʱ������
				if(
					(protects.protect.dch_empty_flag == 1)||
					(protects.protect.dch_ocp2_flag == 1)||
					(protects.protect.dch_scd_flag == 1)||
					(protects.protect.cell_low_2v_flag ==1)||
					(protects.protect.dch_lvp_flag == 1)||
					(protects.protect.dch_ocp_flag == 1)
				)
				{
					Dsg_Control(CLOSE_MOS);
				}
			} 
			else
			{
				if (sys_flags.flag.chg_state_flag == 0)
				{
					Dsg_Control(CLOSE_MOS);	
					//�رշŵ�
				}
				
				if (sys_flags.flag.sys_id_connect_flag == 0)
				{
					Dsg_Control(CLOSE_MOS);
					//�رշŵ�
				}
			}
		}
	}
 }
 
 
  /****************************************************************************
 FUNCTION		: Protect_Retry_Function
 DESCRIPTION	: ���������λָ� �ȶ�λָ��ĺ���
 INPUT			: None
 OUTPUT			: None
 *****************************************************************************/
 
 void Protect_Retry_Function(void)
 {
	static u8 chg_ocp_cnt = 0;
	static u8 dsg_ocp_cnt = 0;
	static u8 dsg2_ocp_cnt =0;
	if (protects.protect.chg_ocp_flag == 1 && chg_retry_cnt <3)
	{
		chg_ocp_cnt++;
		if (chg_ocp_cnt > GC_DELAY_5S) //��ʱ�д�����
		{
			chg_ocp_cnt = 0;
			if (chg_retry_cnt < 3)
			{
				protects.protect.chg_ocp_flag = 0;
				sys_flags.flag.adapter_connect_flag = 0;
			}
			chg_retry_cnt++;
		}
	} 
	else
	{
		chg_ocp_cnt = 0;
	}
	 
	if((protects.protect.dch_ocp_flag == 1) && (dsg_retry_cnt <3))
	{
		dsg_ocp_cnt++;
		if(dsg_ocp_cnt > GC_DELAY_10S)//5S //��ʱ�д�����
		{
			dsg_ocp_cnt = 0;
			if(dsg_retry_cnt <3)
			{
				protects.protect.dch_ocp_flag =0;
				if(sys_flags.flag.open_dch_30s_end_flag == 1)
				{
					sys_flags.flag.sys_comm_open_dch_flag =1;
				}
			}
			dsg_retry_cnt++;
		}
	}
	else
	{
		dsg_ocp_cnt =0;
	}
	 
	if((protects.protect.dch_ocp2_flag == 1) && (dsg2_retry_cnt <3))
	{
		dsg2_ocp_cnt++;
		if(dsg2_ocp_cnt > GC_DELAY_10S)//5S
		{
			dsg2_ocp_cnt = 0;
			if(dsg2_retry_cnt <3)
			{
				protects.protect.dch_ocp2_flag =0;
				if(sys_flags.flag.open_dch_30s_end_flag == 1)
				{
					sys_flags.flag.sys_comm_open_dch_flag =1;
				}
			}
			dsg2_retry_cnt++;
		}
	}
	else
	{
		dsg2_ocp_cnt =0;
	}

	 
 }
 

uint8_t Find_MCU_Temp(uint16_t temp_val)
{
    // �۰������������Ҫ8���ҵ��¶�ֵ
    uint16_t low = 0;
    uint16_t high = MCU_TEMP_DEGREE_RANGE - 1;
    uint16_t mid = 0 ;

    while(low < high)
    {
	    mid = (low + high) >>1;

	    if(temp_val == TEMP_VOLT_TABLE[mid])
	    {break;}                               // �������պ���ȵ�ֵ�������Ϸ���
	    if(1 == (high - low))
	    {
		    mid = low;                 // ���ڲ��Ǿ�ȷ���ң�����С�����ڣ�ȡСֵ
		    break;
	    }
	    if(temp_val < TEMP_VOLT_TABLE[mid])
	    {low = mid;}
	    else
	    {high = mid;}
    }

    return mid;
}





 
 

