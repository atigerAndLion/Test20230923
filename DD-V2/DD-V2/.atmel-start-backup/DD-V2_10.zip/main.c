#include <atmel_start.h>
#include "main.h"
#include "../comm/i2c_sh367309.h"
#include "../comm/user_bms.h"
#include "../comm/CAN_RW_Manage.h"
#include "../comm/soft_soc.h"

#include "comm/i2c_cht8305.h"
#include "comm/i2c_sd2058.h"


volatile SystemFlags  sys_flags;
volatile SystemStates sys_states;
volatile SystemUarts  sys_uarts;
SystemDesign          sys_design;

SystemProtects  protects;
SystemProtects2 protects2;

const uint32_t Send_ID_Test      = 0x00000001;
uint8_t        Send_Data_Test[8] = { 0x00, 0x01, 0x02, 0x03 };

uint8_t count = 0;

void test_fun(void)
{
	count++;
	if (count == 100)
	{
		count = 0;
		CAN_Send(Send_ID_Test, CAN_FMT_STDID, Send_Data_Test, 8);
	}
}


int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	//wdt_set_timeout_period(&WDT_0, 1000, 2048); //1K Ƶ�� 2S��ʱ
	//wdt_enable(&WDT_0);
	
	hri_supc_write_VREF_SEL_bf(SUPC,SUPC_VREF_SEL_2V048_Val);

	//CTL_ON();//������ŵ��,7309�ϵ����쳣Ĭ�ϴ����
	//delay_ms(300);//SH367309�ϵ��ӳ�300ms
	
	CHT8305_Init();
	CHT8305_GetData();
	
	SD2058_Time_Init();
	SD2058_Rtc_Read_Time(&sd2058_val);
	
	
	
	// AFE��ʼ��	
	if(InitAFE())
	{
		//printf("InitAFE initialization succeeded..\r\n");
	}
	else
	{
		//printf("InitAFE initialization failed..\r\n");
	}
	//if(UpdataAfeConfig())//��ȡROM��Ϣ,ȷ���Ƿ����ROM
	//{
		////printf("ROM initialization succeeded..\r\n");		
	//}
	//else
	//{
		////printf("ROM initialization failed..\r\n");		
	//}
	//��ʼCAN���͡����ջص����˲���.
	VCC_EN_ON();
	STB_ON();
	//CP_EN_ON();
	delay_ms(50);
	CAN_RW_Init();
	//CAN ���Ͳ���
	//CAN_Send(Send_ID_Test, CAN_FMT_STDID, Send_Data_Test, 8);

	/* Replace with your application code */
	while (1) {
		gpio_toggle_pin_level(FUSE);
		//wdt_feed(&WDT_0);
		//gpio_set_pin_level(FUSE,false);
		//gpio_set_pin_level(FUSE,true);

		RT_ON_ON();
		delay_ms(15); //������40ms һ������
		CHT8305_GetData();
		ADC_Function();//ADC�ɼ�
		AFE_Update_Function();//����AFE������RAM
		Comm_Proc();
		State_Change_Function();//״̬λ�л�
		MOS_Control_Function();//MOSFET����
		NormalCapacityProc();//��������
		Sleep_Function();//����
		ShutDown_Function();//�ػ�

		//test_fun();
		//count++;
		//if (count == 100)
		//{
			//count = 0;
			//CAN_Send(Send_ID_Test, CAN_FMT_STDID, Send_Data_Test, 8);
		//}

		//delay_ms(19); //����ѭ��40mS
	}
}
void Sleep_Function()
{
	if (sys_flags.flag.sleep_flag == 1)
	{
		/* System entry into Power-down Mode */
	}
}


void ShutDown_Function()
{
	if (sys_flags.flag.sys_close_flag == 1)
	{
	}
}