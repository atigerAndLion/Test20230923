/*
 * i2c_sd2058.c
 *
 * Created: 2020/5/15 15:55:32
 *  Author: chenjiawei
 */ 

#include "comm/i2c_sd2058.h"

SD2058_VAL sd2058_val;

/****************************************************************************
FUNCTION		: I2C1_SendBytes
DESCRIPTION		: ����һ�����ݸ�SD2058
INPUT			: targer �Ĵ�����ַ DataBuffer ���ݴ��ָ��  ExpectedByteNumber ���Ͷ����ֽڵ�����
OUTPUT			: None
*****************************************************************************/

void I2C1_SendBytes(unsigned char targer, unsigned char *DataBuffer, unsigned char ByteCount)
{
	uint8_t i;
	IIC1_Start();
	IIC1_Send_Byte(SD2058_ADDRESS_W);
	IIC1_Send_Byte(targer);
	for(i=0;i<ByteCount;i++)
	{
		IIC1_Send_Byte(*DataBuffer);
		DataBuffer++;
	}
	IIC1_Stop();
}

/****************************************************************************
FUNCTION		: I2C1_ReadBytes
DESCRIPTION		: ��SD2058��ȡһ������
INPUT			: targer �Ĵ�����ַ DataBuffer ���ݴ��ָ��  ExpectedByteNumber ��ȡ�����ֽڵ�����
OUTPUT			: None
*****************************************************************************/

void I2C1_ReadBytes(unsigned char targer, unsigned char *DataBuffer, unsigned int ExpectedByteNumber)
{
	unsigned char i = 0;
	IIC1_Start();
	IIC1_Send_Byte(SD2058_ADDRESS_W);
	IIC1_Send_Byte(targer);
	delay_us(20);
	IIC1_Start();
	IIC1_Send_Byte(SD2058_ADDRESS_R);
	for(i=0;i<ExpectedByteNumber-1;i++)
	{
		*DataBuffer =IIC1_Read_Byte(ACK);
		DataBuffer++;
	}
	*DataBuffer =IIC1_Read_Byte(NACK);
	IIC1_Stop();
}

/****************************************************************************
FUNCTION		: SD2058_Time_Init
DESCRIPTION		: SD2058 ��ʼ������
INPUT			: None
OUTPUT			: None
*****************************************************************************/

void SD2058_Time_Init(void)
{
	IIC1_Init();
	sd2058_val.years = 20;
	sd2058_val.month = 5;
	sd2058_val.date = 29;
	sd2058_val.hours = 2;
	sd2058_val.minutes = 3;
	sd2058_val.seconds = 4;
	sd2058_val.wday = 5;
	SD2058_Rtc_Write_Time(&sd2058_val);
	//��ʱ��������ʼ��
}

/****************************************************************************
FUNCTION		: SD2058_Rtc_Read_Time
DESCRIPTION		: �� SD2058 ��ȡʱ������
INPUT			: SD2058_VAL �ṹ��ָ��
OUTPUT			: None
*****************************************************************************/

void SD2058_Rtc_Read_Time(SD2058_VAL *p)
{
    unsigned char temp[10] = {0} ;
    I2C1_ReadBytes( 0 , temp , 7); //reg address first is 0,buff is temp,length of reg is 7

	p->seconds = bcd2bin(temp[0] & SD2058_SECONDS_MASK);
	p->minutes = bcd2bin(temp[1] & SD2058_MINUTES_MASK);
	p->hours = bcd2bin(temp[2] & SD2058_HOURS_MASK);
	p->wday = bcd2bin(temp[3]);
	p->date = bcd2bin(temp[4]);
	p->month = bcd2bin(temp[5]);
	p->years= bcd2bin(temp[6]);

}

/****************************************************************************
FUNCTION		: SD2058_Rtc_Write_Time
DESCRIPTION		: дʱ�����ݵ� SD2058 
INPUT			: SD2058_VAL �ṹ��ָ��
OUTPUT			: None
*****************************************************************************/

void SD2058_Rtc_Write_Time(SD2058_VAL *p)
{
    unsigned char temp[10] ;
    temp[0] = bin2bcd(p->seconds);
    temp[1] = bin2bcd(p->minutes);
    temp[2] = bin2bcd(p->hours);
    temp[3] = bin2bcd(p->wday);
    temp[4] = bin2bcd(p->date);
    temp[5] = bin2bcd(p->month);
    temp[6] = bin2bcd(p->years);
	
	temp[7] = 0x80;
	I2C1_SendBytes( 0x10 , temp+7 , 1);
	temp[7] = 0x84;
	I2C1_SendBytes( 0x0f , temp+7 , 1);
	
    I2C1_SendBytes( 0 , temp , 7);

	temp[7] = 0x00;
	I2C1_SendBytes( 0x0f , temp+7 , 1);
	
	temp[7] = 0x00;
	I2C1_SendBytes( 0x10 , temp+7 , 1);	

}


/**
  * @brief  This function is bcd2bin.
  * @param  unsigned char val
  * @retval None
  */
  
unsigned char bcd2bin(unsigned char val)
{
    return (val & 0x0f) + (val >> 4) * 10;
}
 
/**
  * @brief  This function is bin2bcd.
  * @param  unsigned char val
  * @retval None
  */
  
unsigned char bin2bcd(unsigned char val)
{
    return ((val / 10) << 4) + val % 10;
}

